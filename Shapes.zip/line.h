#include"cylinder.h"
#include<iostream>
using namespace std;
class line{
private:
	point *p1;
	point *p2;
	int linelenght;
public:
	line();
	
	line(int &,int &,int &,int &,int &);
	
	int getpoint1x();
	
	
	int getpoint1y();

	
	int getpoint2x();
	
	
	int getpoint2y();

	
	int getlenline();
	
	
	void setlenline(int &);

	
	void setpoint2(int &,int &);
	


	void setpoint1(int &,int &);
	
	
	void print(){
		p1->print_point();
		cout<<endl;

		p2->print_point();
		cout<<"\n lenght of line = "<<linelenght<<endl;


	
	}

};