//#include"cylinder.h"
#include "polygon.h"
#include<iostream>
using namespace std;
int main(){
	int r=5;
	int cx=2,cy=2;
	circle obj(r,cx,cy);
	circle obj2(r,cx,cy);
	
	cylinder obj3(r,cx,cy,r) ;
	cylinder obj4(r,cx,cy,r);

	cylinder obj5;
	obj5=(obj3+obj4);
	cout<<"212123 ";
	obj4.print_cylinder();
	obj3.print_cylinder();

	obj3.printvolume();

	//obj3.print_area();
	obj.print_circle();
	obj.print_area();

	line obj6(r,r,r,r,r);
	obj6.print();

system("pause");
return 0;}