#include"circle.h"
#include<iostream>
using namespace std;
class cylinder{

private:

	circle * base;

	int height;

public:



	cylinder();
		
	cylinder(int &,int &,int &,int &);
		
	cylinder(cylinder &);


		
	int getheight();

		
		int get_radius();

		
		int get_x();

		
		int get_y();

		
		void set_radius(int &);
			
	
		void center_set(int &,int &);

		

		int calculate_volume();

		void printvolume();

		int calculate_surfacearea();

		void print_surfacearea();



		void setcylinder(int &,int &,int &,int &);

		friend cylinder & operator +(cylinder & obj1,cylinder & obj2){
		cylinder temp;
	//	temp.base->operator+(obj1.base,obj2.base);

		temp.height=obj1.height+obj2.height;
		
		return temp;
		}
		

	
		void print_cylinder(){
		
			
			base->print_circle();

			cout<<"height = "<<height<<endl;
		
		}
};