#include"point.h"
#include<iostream>
using namespace std;
class circle{
private:
	
	int radius;
	
	point *center;

public:
	
	circle();

	circle(int &,int &,int &);

	circle(circle &);

	int getradius();

	int getcenterx();
	int getcentery();
	void setradius(int &);

	void setcenter(int &,int &);

	int calculate_area();

	void print_area();

	int circumfrance_area();

	void print_circumfrance();

	int increment_area();

	int decrement_area();

	friend circle & operator +(circle & obj1,circle & obj2){
	
		circle temp;

		temp.radius=obj1.radius+obj2.radius;
	
		int a1= obj1.center->getpx();
		int b1=obj1.center->getpy();

		int a2 = obj2.center->getpx();
		int b2=obj2.center->getpy();


		int a = a1+a2;
		int b=b1+b2;

		temp.center->setpoint(a,b);
return temp;
	}

	friend bool  operator ==(circle & obj1,circle & obj2){
	
		return(obj1.radius==obj2.radius && 
			obj1.center->getpx()==obj2.center->getpx() &&
			obj1.center->getpy()==obj2.center->getpy());
	}

	void print_circle(){
	cout<<"radius = "<<radius<<endl;
	cout<<"center = "<<getcenterx()<<","<<getcentery();
	
	}

};
