#include<iostream>
using namespace std;
class point{


	private:
		
		int x;
		
		int y;
	
	public:
		
		point();
		
		point(int &,int &);
		
		point(point &);


		int getpx();

		int getpy();

		void setpoint(int &,int &);

		void print_point(){
		cout<<x<<"  "<<y;
		}
};