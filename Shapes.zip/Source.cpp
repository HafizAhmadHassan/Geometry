//#include".h"
#include<cmath>
#include"polygon.h"

#include<iostream>
using namespace std;
point::point(){

	x=0;
	y=0;
}
		
point::point(int & a,int & b){
	
	x=a;
	y=b;

}		
point::point(point & obj){


	obj.x=x;

	obj.y=y;

}
int point::getpx(){
return x;

}
int point ::getpy(){

	return y;

}
void point::setpoint(int & a,int & b){

	x=a;
	
	y=b;

}
circle::circle(){
	
	center=0;
	
	radius=0;



}
circle::circle(int & a,int & b,int & c){
	
	radius=a;
	
	center=new point(b,c);

	
}
circle::circle(circle & obj){
	if(obj.center==0){
	
		delete obj.center;

	}
	
	obj.radius=radius;

	obj.center=center;


}

int circle :: getradius(){

	
	return radius;


}
int circle :: getcenterx(){
	if(center==0){
	delete center;
	center=new point;
	}
	int a=center->getpx();
	return a;


}
int circle ::getcentery(){
	if(center==0){
	delete center;
	center=new point;
	}
	int b=center->getpy();
	return b;


}

void circle :: setradius(int & r){

	radius=r;

}

void circle ::  setcenter(int & x,int & y){
	if(center==0){
	delete center;
	center=new point(x,y);
	}
	else{
		center->setpoint(x,y);
	}


}

int circle :: calculate_area(){
	
	int a= 3.14*(radius*radius);
	return a;
}

void circle ::  print_area(){
	int a=circle::calculate_area();

	cout<<"area = "<<a<<endl;

}

int circle :: circumfrance_area(){

	return 2*3.14*radius;

}

void circle :: print_circumfrance(){
	int a=circle::decrement_area();
	cout<<" circum = "<<a<<endl;

}

int circle :: increment_area(){

	int a=circle::calculate_area();

	return 2*a;

}

int circle :: decrement_area(){
	int a=circle::calculate_area();

	return a/2;



}




cylinder::cylinder(){

	base=0;
	height=0;



}
		
cylinder::cylinder(int & a,int & b,int & c,int & d ){


	
	base=new circle(a,b,c);
	
	height=d;


}
		
cylinder::cylinder(cylinder & obj){

	obj.base=base;

	obj.height=height;





}


int cylinder::getheight(){

	return height;
}

int cylinder::get_radius(){


	int a= base->getradius();
	return a;
}
int cylinder :: get_x(){

	int a=base->getcenterx();

	return a;

}
int cylinder :: get_y(){

	int b=base->getcentery();

	return b;

}

void cylinder::setcylinder(int & a1,int & b1,int &c1,int &d1){

	if(base==NULL){
	delete base;
	base=new circle(a1,b1,c1);
	}
	else{
	base=new circle(a1,b1,c1);
	
	}

	height=d1;




}
void cylinder::set_radius(int & r){

	if(base==NULL){
	delete base ;

	base=new circle;
	}
	base->setradius(r);

}
			
	
void cylinder::center_set(int & c1,int & c2){
	
	if(base==NULL){
	delete base ;

	base=new circle;
	}
	base->setcenter(c1,c2);
}


int cylinder :: calculate_volume(){

	if(base==NULL){
	delete base ;

	base=new circle;
	}
	int a=base->calculate_area();
	return a*height;

}

void cylinder :: printvolume(){

	if(base==NULL){
	delete base ;

	base=new circle;
	}
	int a=calculate_volume();

	cout<<"Volume = "<<a<<endl;
}

int cylinder::calculate_surfacearea(){

	if(base==NULL){
	delete base ;

	base=new circle;
	}
	int a= base->circumfrance_area();
	
	int b=base->getradius();

	return a*height+a*b;




}

void cylinder::print_surfacearea(){

	if(base==NULL){
	delete base ;

	base=new circle;
	}

	int a=calculate_surfacearea();

	cout<<"surface area = "<<a<<endl;

}
line::line(){

p1=NULL;

p2=NULL;

linelenght=0;

}
line ::line(int & a,int & b,int & c,int & d,int &e){

	if(p1==NULL)
	{
	delete p1;
	delete p2;
	
	}
	
	p1=new point(a,b);

	p2=new point(c,d);
	

	
	e=(a-c)*(a-c)-(b-d)*(b-d);
	
	e=sqrt(e);
	
	linelenght=e;

}
int line ::getpoint1x(){

	return p1->getpx();

}
	
int line ::getpoint1y(){

	return p1->getpy();
}

int line ::getlenline(){

	return linelenght;

}
	
void line ::setlenline(int & n){
	
	linelenght=n;

}

void line ::setpoint2(int & n1,int & n2){
	
	p2->setpoint(n1,n2);
	

}

void line ::setpoint1(int &n1,int & n2){
	
	
	p2->setpoint(n1,n2);
	

	
}





int line ::getpoint2x(){


	return p2->getpx();

}	
int line ::getpoint2y(){

	return p2->getpy();

}
polygon::polygon(){

	l=0;
	totalside=0;




}
/*polygon::polygon(int & a,int & b,int & c,int & d,int & e,  int & a1,int & b1,int & c1,int & d1,int & e1,   int & a2,int & b2,int & c2,int & d2,int & e2,     int & a3,int & b3,int & c3,int & d3,int & e3,   int & a4,int & b4,int & c4,int & d4,int & e4,  int & a5,int & b5,int & c5,int & d5,int & e5){

	l1=new line(a,b,c,d,e);
	
	l2=new line(a1,b1,c1,d1,e1);

	l3=new line(a2,b2,c,d2,e2);
	
	l4=new line(a3,b3,c3,d3,e3);
	
	l5=new line(a4,b4,c4,d4,e4);
	
	l6=new line(a5,b5,c5,d5,e5);
	
	totalside=6;

}*/

polygon::polygon(int & a,int & b,int & c,int & d,int & e,int & index){


	if(l==0){
	

		
		delete l;

	

	}
	l=new line[6];
	if(index<6)
	l[index].line::line(a,b,c,d,e);



}
void polygon::storeline(int & n1,int & n2,int & n3,int & n4,int & index){

	if(l==0){
	
		
		delete [] l;
		l[index].line::line();
	}
	l[index].setpoint1(n1,n2);
	l[index].setpoint2(n3,n4);


}

/*void polygon::line2(int & n5,int & n6,int & n7,int & n8){

	
	if(l2==NULL){
	delete l2;
		l2=new line();
	
	}
	l2->setpoint1(n5,n6);
	l2->setpoint2(n7,n8);


}
void polygon::line3(int & n9,int & n10,int & n11,int & n12){

	if(l3==NULL){
	delete l3;
		l3=new line();
	
	}
	l3->setpoint1(n9,n10);
	l3->setpoint2(n11,n12);



}

void polygon::line4(int & n13,int & n14,int & n15,int & n16){

if(l4==NULL){
	delete l4;
		l4=new line();
	
	}
	l4->setpoint1(n13,n14);
	l4->setpoint2(n15,n16);
}

void polygon::line5(int & n17,int & n18,int & n19,int & n20){

if(l5==NULL){
	delete l5;
		l5=new line();
	
	}
	l5->setpoint1(n17,n18);
	l5->setpoint2(n19,n20);
}

void polygon::line6(int & n21,int & n22,int & n23,int & n24){

if(l6==NULL){
	delete l6;
		l6=new line();
	
	}
	l6->setpoint1(n21,n22);
	l6->setpoint2(n23,n24);
}
	
int polygon::line1_get1x(){
	int a=l1->getpoint1x();
	return a;
}

int polygon::line2_get1x(){
	int a=l2->getpoint1x();
	return a;

}

int polygon::line3_get1x(){
	int a=l3->getpoint1x();
	return a;
}
int polygon::line4_get1x(){
	int a=l4->getpoint1x();
	return a;
}


int polygon::line5_get1x(){


	int a=l5->getpoint1x();
	return a;

}

int polygon::line6_get1x(){


	int a=l6->getpoint1x();
	return a;


}

int polygon::line1_get1y(){
	
	
	int a=l1->getpoint1y();
	return a;
}

int polygon::line2_get1y(){
	
	int a=l2->getpoint1y();
	return a;
}
int polygon::line3_get1y(){
	
	int a=l3->getpoint1y();
	return a;
}

int polygon::line4_get1y(){
	
	int a=l4->getpoint1y();
	return a;
}

int polygon::line5_get1y(){
	
	
	int a=l5->getpoint1y();
	return a;
}
int polygon::line6_get1y(){
	
	
	int a=l6->getpoint1y();
	return a;
}


















int polygon::line1_get2x(){
	int a=l1->getpoint2x();
	return a;
}

int polygon::line2_get2x(){
	int a=l2->getpoint2x();
	return a;

}

int polygon::line3_get2x(){
	int a=l3->getpoint2x();
	return a;
}
int polygon::line4_get2x(){
	int a=l4->getpoint2x();
	return a;
}


int polygon::line5_get2x(){


	int a=l5->getpoint2x();
	return a;

}

int polygon::line6_get2x(){


	int a=l6->getpoint2x();
	return a;


}

int polygon::line1_get2y(){
	
	
	int a=l1->getpoint2y();
	return a;
}

int polygon::line2_get2y(){
	
	int a=l2->getpoint2y();
	return a;
}
int polygon::line3_get2y(){
	
	int a=l3->getpoint2y();
	return a;
}

int polygon::line4_get2y(){
	
	int a=l4->getpoint2y();
	return a;
}

int polygon::line5_get2y(){
	
	
	int a=l5->getpoint2y();
	return a;
}
int polygon::line6_get2y(){
	
	
	int a=l6->getpoint2y();
	return a;
}*/