#include"line.h"
class polygon{
private:

	
	//line *l1;
	//line *l2;
	//line *l3;
//	line *l4;
	
	//line *l5;
	//line *l6;
	
	//this become hectic by using 6 pointer now i realize importance of array 
	//another way to make array lets not do this because i array use many time now its time to use simple logic
	int totalside;

	line *l;

public:
	polygon();

	//polygon(int &,int &,int &,int &,int &,   int &,int &,int &,int &,int &,  int &,int &,int &,int &,int &,  int &,int &,int &,int &,int &,  int &,int &,int &,int &,int &,    int &,int &,int &,int &,int &);

	polygon(int &,int &,int &,int &,int &,int &);
	void line5(int &,int &,int &,int &);

	void line6(int &,int &,int &,int &);

	
	void storeline(int &,int &,int &,int &,int &);

	void line2(int &,int &,int &,int &);
	
	void line3(int &,int &,int &,int &);

	void line4(int &,int &,int &,int &);

	int line1_get1x();

	int line2_get1x();


	int line3_get1x();

	int line4_get1x();


	int line5_get1x();

	int line6_get1x();

	int line1_get1y();

	int line2_get1y();

	int line3_get1y();

	int line4_get1y();

	int line5_get1y();
	
	int line6_get1y();


	
	
	
	int line1_get2x();

	int line2_get2x();


	int line3_get2x();

	int line4_get2x();


	int line5_get2x();

	int line6_get2x();

	int line1_get2y();

	int line2_get2y();

	int line3_get2y();

	int line4_get2y();

	int line5_get2y();
	
	int line6_get2y();

	
	void triangle();	

	void hexagone();

	void rectangle();
};